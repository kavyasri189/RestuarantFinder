import React from 'react';

const MealsContainer = props => {
  return <div>MealsContainer</div>;
};

export default MealsContainer;
