import React from 'react';

const ResultsContainer = props => {
  return <div>ResultsContainer</div>;
};

export default ResultsContainer;
