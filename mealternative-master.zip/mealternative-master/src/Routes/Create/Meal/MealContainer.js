import React from 'react';
// import PropTypes from 'prop-types';

const MealRoute = props => {
  // const { classes } = props;

  return <div>MealRoute</div>;
};

// MealRoute.propTypes = {
//   classes: PropTypes.object.isRequired
// };

export default MealRoute;
