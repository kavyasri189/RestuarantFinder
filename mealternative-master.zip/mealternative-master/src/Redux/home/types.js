/*
  actions types for homepage
*/
export const HOME_BEGIN = 'HOME_BEGIN';
export const HOME_ERROR = 'HOME_ERROR';
export const HOME_CLEAN = 'HOME_CLEAN';

export const HOME_GET_CATEGORY = 'HOME_GET_CATEGORY';
export const HOME_STORE_CATEGORY = 'HOME_STORE_CATEGORY';
